package com.example.iinternetbanking.Activities;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.iinternetbanking.Fragments.MainFragment;
import com.example.iinternetbanking.Fragments.SignInFragment;
import com.example.iinternetbanking.Models.Cartes;
import com.example.iinternetbanking.Models.Compte;
import com.example.iinternetbanking.Models.User;
import com.example.iinternetbanking.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.concurrent.atomic.AtomicMarkableReference;

public class LoginActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;
    private FirebaseDatabase database;
    private DatabaseReference myRefUser;
    private DatabaseReference myRefCompte;
    private DatabaseReference myRefCarte;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
       getSupportFragmentManager().beginTransaction().add(R.id.fragment_login_container,new SignInFragment()).addToBackStack(null).commit();
    }

    @Override
    protected void onStart() {
        super.onStart();
        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();
        if (currentUser!= null){
            getCurrentFullUser();
        }
    }

    private void getCurrentFullUser(){
        database = FirebaseDatabase.getInstance();
        myRefUser = database.getReference("Users");
        mAuth = FirebaseAuth.getInstance();
        myRefUser.child(currentUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User MaincurrentUser = dataSnapshot.getValue(User.class);
                GetCompte(MaincurrentUser);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void GetCompte(final User maincurrentUser) {

        database = FirebaseDatabase.getInstance();
        myRefCompte = database.getReference("Comptes");
        myRefCompte.child(maincurrentUser.getId()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                getCarte(maincurrentUser,dataSnapshot.getChildren().iterator().next().getValue(Compte.class));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void getCarte(final User maincurrentUser, final Compte compte) {
        database = FirebaseDatabase.getInstance();
        myRefCarte = database.getReference("Cartes");
        myRefCarte.child(maincurrentUser.getId()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                updateUI(maincurrentUser,compte,dataSnapshot.getChildren().iterator().next().getValue(Cartes.class));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void updateUI(User maincurrentUser, Compte compte, Cartes cartes) {
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("currentfulluser",maincurrentUser);
        i.putExtra("compte",compte);
        i.putExtra("carte",cartes);
        startActivity(i);
        overridePendingTransition(R.anim.alpha, R.anim.slide_down);
        finish();
    }




}
