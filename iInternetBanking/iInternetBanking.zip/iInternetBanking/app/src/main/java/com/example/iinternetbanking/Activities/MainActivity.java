package com.example.iinternetbanking.Activities;

import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.iinternetbanking.Fragments.MainFragment;
import com.example.iinternetbanking.Fragments.SignInFragment;
import com.example.iinternetbanking.Models.Cartes;
import com.example.iinternetbanking.Models.Compte;
import com.example.iinternetbanking.Models.User;
import com.example.iinternetbanking.R;

public class MainActivity extends AppCompatActivity {

    public static User CurrentFullUser = null;
    public static Compte CurrentCompte = null;
    public static Cartes CurrentCarte = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (getIntent().getParcelableExtra("currentfulluser") != null){
             CurrentFullUser = getIntent().getParcelableExtra("currentfulluser");
        }
        if (getIntent().getParcelableExtra("compte") != null){
            CurrentCompte = getIntent().getParcelableExtra("compte");
        }
        if (getIntent().getParcelableExtra("carte") != null){
            CurrentCarte = getIntent().getParcelableExtra("carte");
        }
        getSupportFragmentManager().beginTransaction().add(R.id.fragment_container,new MainFragment()).addToBackStack(null).commit();
    }
}
