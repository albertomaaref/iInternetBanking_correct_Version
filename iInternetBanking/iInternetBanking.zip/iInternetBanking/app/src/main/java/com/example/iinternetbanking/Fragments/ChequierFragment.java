package com.example.iinternetbanking.Fragments;


import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.iinternetbanking.Models.demandeChequier;
import com.example.iinternetbanking.R;
import com.example.iinternetbanking.databinding.FragmentChequierBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.UUID;

import static com.example.iinternetbanking.Activities.MainActivity.CurrentCompte;
import static com.example.iinternetbanking.Activities.MainActivity.CurrentFullUser;

public class ChequierFragment extends Fragment implements View.OnClickListener {

    private FragmentChequierBinding binding;
    private String nbrPage;
    private String numCompte;
    private DatabaseReference myRef;

    public ChequierFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("demandeChequiers");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_chequier, container, false);
        binding.numCompteEdittext.setText(CurrentCompte.getNum_compte());
        binding.demandeChequierContainer.setOnClickListener(this);
        return binding.getRoot();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.demande_chequier_container:
                SaveDemande();
            break;
        }
    }

    private void SaveDemande() {
        if (binding.nbrPageEdittext.getText().toString().contentEquals("")){
            return;
        }
        if (binding.numCompteEdittext.getText().toString().contentEquals("")){
            return;
        }
        binding.aviChequier.setVisibility(View.VISIBLE);
        binding.demandeChequierTxt.setVisibility(View.INVISIBLE);
        binding.demandeChequierContainer.setEnabled(false);
        nbrPage = binding.nbrPageEdittext.getText().toString();
        numCompte = binding.numCompteEdittext.getText().toString();
        demandeChequier demandeChequier = new demandeChequier(UUID.randomUUID().toString(),nbrPage,numCompte, Calendar.getInstance().getTime(),null,CurrentFullUser);
        myRef.child(CurrentFullUser.getId().toString()).child(demandeChequier.getId()).setValue(demandeChequier).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                binding.aviChequier.setVisibility(View.INVISIBLE);
                binding.demandeChequierTxt.setVisibility(View.VISIBLE);
                binding.demandeChequierContainer.setEnabled(true);
                Toast.makeText(getContext(), "demande envoye avec succes", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                binding.aviChequier.setVisibility(View.INVISIBLE);
                binding.demandeChequierTxt.setVisibility(View.VISIBLE);
                binding.demandeChequierContainer.setEnabled(true);
                Toast.makeText(getContext(), "demande n'est pas envoye, verifier votre conexion!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
