package com.example.iinternetbanking.Fragments;


import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.iinternetbanking.Models.Compte;
import com.example.iinternetbanking.R;
import com.example.iinternetbanking.databinding.FragmentCompteBinding;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import static com.example.iinternetbanking.Activities.MainActivity.CurrentCompte;
import static com.example.iinternetbanking.Activities.MainActivity.CurrentFullUser;

public class CompteFragment extends Fragment {

    private FragmentCompteBinding binding;

    public CompteFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_compte, container, false);
        binding.nomTxt.setText(CurrentCompte.getNom_compte());
        binding.numTxt.setText(CurrentCompte.getNum_compte());
        binding.ribTxt.setText(CurrentCompte.getRIB());
        binding.soldeTxt.setText(CurrentCompte.getSolde());
        binding.soldeDevisesTxt.setText(CurrentCompte.getDevises_compte());
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference CompteRef = database.getReference("Comptes");
        CompteRef.child(CurrentFullUser.getId()).child(CurrentCompte.getNum_compte()).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                if (dataSnapshot.getKey().contentEquals("solde")){
                    CurrentCompte.setSolde(dataSnapshot.getValue().toString());
                    binding.soldeTxt.setText(CurrentCompte.getSolde());
                }
                if (dataSnapshot.getKey().contentEquals("devises_compte")){
                    CurrentCompte.setDevises_compte(dataSnapshot.getValue().toString());
                    binding.soldeDevisesTxt.setText(CurrentCompte.getDevises_compte());
                }
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        return binding.getRoot();
    }

}
