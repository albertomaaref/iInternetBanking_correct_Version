package com.example.iinternetbanking.Fragments;


import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.iinternetbanking.Adapters.MainViewPagerAdapter;
import com.example.iinternetbanking.R;
import com.example.iinternetbanking.databinding.FragmentMainBinding;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;


public class MainFragment extends Fragment implements TabLayout.BaseOnTabSelectedListener {

    private FragmentMainBinding binding;
    private ArrayList<Fragment> fragments = new ArrayList<>();
    private MainViewPagerAdapter fragmentAdapter;
    private FirebaseAuth mAuth;

    private int[] tabIcons = {
            R.drawable.ic_compte,
            R.drawable.ic_transactions,
            R.drawable.ic_virements,
            R.drawable.ic_devises,
            R.drawable.ic_chequier,
            R.drawable.ic_chequier,
            R.drawable.ic_contact
    };


    public MainFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAuth = FirebaseAuth.getInstance();
        fragments.add(new CompteFragment());
        fragments.add(new TransactionsFragment());
        fragments.add(new VirementsFragment());
        fragments.add(new DevisesFragment());
        fragments.add(new ChequierFragment());
        fragments.add(new OppositionCarteFragment());
        fragments.add(new ContactFragment());
        }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding =  DataBindingUtil.inflate(inflater,R.layout.fragment_main, container, false);
        fragmentAdapter = new MainViewPagerAdapter(getFragmentManager(),fragments);
        binding.viewPager.setAdapter(fragmentAdapter);
        binding.tabLayout.setupWithViewPager(binding.viewPager);
        binding.tabLayout.addTab(binding.tabLayout.newTab().setIcon(R.drawable.ic_logout),7);
        binding.tabLayout.addOnTabSelectedListener(this);
        setupTabIcons();
        return binding.getRoot();
    }

    private void setupTabIcons() {
        binding.tabLayout.getTabAt(0).setIcon(tabIcons[0]);
        binding.tabLayout.getTabAt(1).setIcon(tabIcons[1]);
        binding.tabLayout.getTabAt(2).setIcon(tabIcons[2]);
        binding.tabLayout.getTabAt(3).setIcon(tabIcons[3]);
        binding.tabLayout.getTabAt(4).setIcon(tabIcons[4]);
        binding.tabLayout.getTabAt(5).setIcon(tabIcons[5]);
        binding.tabLayout.getTabAt(6).setIcon(tabIcons[6]);

    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        if(tab.getPosition() == 7){
            mAuth.signOut();
            getActivity().finish();
        }
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }
}
