package com.example.iinternetbanking.Fragments;


import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.iinternetbanking.Models.oppositionCarte;
import com.example.iinternetbanking.R;
import com.example.iinternetbanking.databinding.FragmentOppositionCarteBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.UUID;

import static com.example.iinternetbanking.Activities.MainActivity.CurrentCarte;
import static com.example.iinternetbanking.Activities.MainActivity.CurrentFullUser;

public class OppositionCarteFragment extends Fragment implements View.OnClickListener {

    private FragmentOppositionCarteBinding binding;
    private DatabaseReference OppositionCarteRef;

    public OppositionCarteFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        OppositionCarteRef = database.getReference("OppositionCartes");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_opposition_carte, container, false);
        binding.numCarteEdittext.setText(CurrentCarte.getNum_carte().toString());
        binding.demandeOppositionCarteContainer.setOnClickListener(this);
        return binding.getRoot();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.demande_opposition_carte_container:
                SaveOppositionCarte();
                break;
        }
    }

    private void SaveOppositionCarte() {
        if (binding.motifEdittext.getText().toString().contentEquals("")) {
            return;
        }
        binding.demandeOppositionCarteTxt.setVisibility(View.INVISIBLE);
        binding.aviOppositionCarte.setVisibility(View.VISIBLE);
        binding.demandeOppositionCarteContainer.setEnabled(false);
        oppositionCarte oppositionCarte = new oppositionCarte(UUID.randomUUID().toString(), CurrentCarte.getNum_carte(), binding.motifEdittext.getText().toString(), Calendar.getInstance().getTime(), null, "Valide", CurrentFullUser);
        OppositionCarteRef.child(CurrentFullUser.getId()).child(oppositionCarte.getId()).setValue(oppositionCarte).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(getContext(), "Opposition Carte envoye avec succes", Toast.LENGTH_SHORT).show();
                binding.demandeOppositionCarteContainer.setEnabled(true);
                binding.demandeOppositionCarteTxt.setVisibility(View.VISIBLE);
                binding.aviOppositionCarte.setVisibility(View.INVISIBLE);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getContext(), "Opposition Carte n'est pas envoye, verifier votre conexion!", Toast.LENGTH_SHORT).show();
                binding.demandeOppositionCarteContainer.setEnabled(true);
                binding.demandeOppositionCarteTxt.setVisibility(View.VISIBLE);
                binding.aviOppositionCarte.setVisibility(View.INVISIBLE);
            }
        });
    }
}
