package com.example.iinternetbanking.Utils;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.Query;


public interface ApiInterface {
    @Headers("Content-Type: text/html")
    @GET("calc_convertisseur.php")
    Call<String> CalculDevise(@Query("montant_saisi") String montantSaisi, @Query("devise_depart") String deviseDepart, @Query("devise_sortie") String deviseSortie);
}
